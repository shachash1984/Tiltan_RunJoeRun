package com.voxelbusters.nativeplugins.features.webview;

import android.os.Parcel;
import android.webkit.ValueCallback;

import java.io.Serializable;

/**
 * Created by ayyappa on 11/11/16.
 */
public class SerialisedValueCallback<T> implements Serializable
{

    ValueCallback<T> cachedCallback = null;
    public SerialisedValueCallback(ValueCallback<T> callback)
    {
        cachedCallback = callback;
    }

    public void onReceiveValue(T value)
    {
        cachedCallback.onReceiveValue(value);
    }
}
