package com.voxelbusters.nativeplugins.features.gameservices.serviceprovider.google;

import android.content.Context;
import android.content.Intent;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.games.Games;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.games.achievement.Achievement;
import com.google.android.gms.games.achievement.AchievementBuffer;
import com.google.android.gms.games.achievement.Achievements;
import com.google.android.gms.games.achievement.Achievements.LoadAchievementsResult;
import com.google.android.gms.games.achievement.Achievements.UpdateAchievementResult;
import com.voxelbusters.nativeplugins.NativePluginHelper;
import com.voxelbusters.nativeplugins.defines.CommonDefines;
import com.voxelbusters.nativeplugins.defines.Keys;
import com.voxelbusters.nativeplugins.features.gameservices.core.datatypes.AchievementData;
import com.voxelbusters.nativeplugins.features.gameservices.core.interfaces.IGameServicesPlayerListener;
import com.voxelbusters.nativeplugins.features.gameservices.serviceprovider.google.util.DataConversionUtils;
import com.voxelbusters.nativeplugins.utilities.Debug;
import com.voxelbusters.nativeplugins.utilities.JSONUtility;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class GooglePlayAchievements
{
	String								TAG					= "GooglePlayAchievements";
	HashMap<String, AchievementInfo> achievementsData	= new HashMap<String, AchievementInfo>();
	GoogleApiClient						apiService;
	IGameServicesPlayerListener			listener;

	String								instanceId			= null;

	public GooglePlayAchievements(GoogleApiClient apiService)
	{
		this.apiService = apiService;
	}

	public void setListener(IGameServicesPlayerListener listener)
	{
		this.listener = listener;
	}

	public void removeListener(IGameServicesPlayerListener listener)
	{
		if (listener == this.listener)
		{
			this.listener = null;
		}
	}

	public void reportProgress(String instanceId, String achievementId, int pointsScored, boolean immediate)
	{
		AchievementInfo achievement = GetAchievement(achievementId);

		if (achievement != null)
		{

			if (achievement.type == Achievement.TYPE_INCREMENTAL) {

				Debug.log(TAG, "Achievement Type : " + achievement.type);
				if ((pointsScored >= 0) && (achievement.state == Achievement.STATE_HIDDEN)) {
					//TODO : mention in docs if any progress set beyond 0.0f revels the achievement
					Debug.log(TAG, "Revel the achievement now!");
					revealAchievement(instanceId, achievementId, false);
				}


				int totalSteps = achievement.totalSteps;
				int previousReportedSteps = achievement.currentSteps; // Change this

				Debug.log(TAG, "totalSteps : " + totalSteps + " completedSteps : " + previousReportedSteps);

				if (pointsScored < previousReportedSteps) {
					Debug.error(TAG, "Reported negative progress!!!");
					if (listener != null) {
						listener.onReportProgress(instanceId, DataConversionUtils.getAchievementData(achievement), "Reported wrong progress value!");
					}
				} else {

					int incrementedSteps = pointsScored - previousReportedSteps;

					Debug.log("Report", "incrementedSteps : " + incrementedSteps);

					if (incrementedSteps != 0) {
						incrementAchievement(instanceId, achievementId, incrementedSteps, immediate);
					} else {
						if (listener != null) {
							listener.onReportProgress(instanceId, DataConversionUtils.getAchievementData(achievement), null);
						}
					}
				}

			} else {

				if (pointsScored == 0) {
					//TODO : Mention in Docs about the progress value and reveal/unlock details
					Debug.log(TAG, "This is not an incremental achievement. So just trying to reveal it as 100% progress was not sent as progress.");
					revealAchievement(instanceId, achievementId, immediate);
				} else if (pointsScored > 0) {
					Debug.log(TAG, "Unlocking Achievement");
					unlockAchievement(instanceId, achievementId, immediate);
				} else {
					if (listener != null) {
						listener.onReportProgress(instanceId, DataConversionUtils.getAchievementData(achievement), "Reported wrong progress value. Cannot be negative!");
					}
				}
			}

			if (!immediate) {
				loadAchievementsDetails(false, false);
			}
		}
		else
		{
			listener.onReportProgress(instanceId, new AchievementData(), "Achievements Data doesn't contain this achievement id. Did you load Achievement Descriptions ahead? ID : " + achievementId);
		}
	}

	public void revealAchievement(String instanceId, String achievementId, boolean immediate)
	{
		if (!immediate)
		{
			Games.Achievements.reveal(apiService, achievementId);
		}
		else
		{
			PendingResult<Achievements.UpdateAchievementResult> pendingResult = Games.Achievements.revealImmediate(apiService, achievementId);
			setAchievementProgressCallback(instanceId, achievementId, pendingResult);
		}
	}

	public void unlockAchievement(String instanceId, String achievementId, boolean immediate)
	{

		if (!immediate)
		{
			Games.Achievements.unlock(apiService, achievementId);
		}
		else
		{
			PendingResult<Achievements.UpdateAchievementResult> pendingResult = Games.Achievements.unlockImmediate(apiService, achievementId);
			setAchievementProgressCallback(instanceId, achievementId, pendingResult);
		}

        AchievementInfo achievement = GetAchievement(achievementId);
        achievement.SetCurrentSteps(1); // This will create a cache internally.
	}

	public void incrementAchievement(String instanceId, String achievementId, int steps, boolean immediate)
	{

		if (!immediate)
		{

			Games.Achievements.increment(apiService, achievementId, steps);
		}
		else
		{
			PendingResult<Achievements.UpdateAchievementResult> pendingResult = Games.Achievements.incrementImmediate(apiService, achievementId, steps);
			setAchievementProgressCallback(instanceId, achievementId, pendingResult);
		}

		AchievementInfo achievement = GetAchievement(achievementId);
		achievement.SetCurrentSteps(achievement.currentSteps + steps); // This will create a cache internally.
	}

	private void setAchievementProgressCallback(final String instanceId, final String achievementId, PendingResult<Achievements.UpdateAchievementResult> pendingResult)
	{
		pendingResult.setResultCallback(new ResultCallback<Achievements.UpdateAchievementResult>()
			{

				@Override
				public void onResult(UpdateAchievementResult result)
				{
					int status = result.getStatus().getStatusCode();
					if (status == GamesStatusCodes.STATUS_OK)
					{
						if (listener != null)
						{
							listener.onReportProgress(instanceId, getAchievementData(result.getAchievementId()), null);
						}
					}
					else
					{
						Debug.log(CommonDefines.GAME_SERVICES_TAG, "Report Progress successful : " + GamesStatusCodes.getStatusString(status));
						if (listener != null)
						{
							listener.onReportProgress(instanceId, getAchievementData(achievementId), GamesStatusCodes.getStatusString(status));
						}
					}

					loadAchievementsDetails(false, false);//Just update the achievements data user own.
				}

			});
	}

	public void loadAchievementsDetails(final boolean loadAll)
	{
		loadAchievementsDetails(loadAll, true);
	}

	//Here loadall is for forcing fetch of all available achievements. else it will just fetch user achieved/aware achievments which are cached currently.
	private void loadAchievementsDetails(final boolean loadAll, final boolean reportListener)
	{
		PendingResult<Achievements.LoadAchievementsResult> pendingResult = Games.Achievements.load(apiService, loadAll);
		pendingResult.setResultCallback(new ResultCallback<Achievements.LoadAchievementsResult>()
			{

				@Override
				public void onResult(LoadAchievementsResult results)
				{

					ArrayList<AchievementData> listData = null;
					String error = null;

					int status = results.getStatus().getStatusCode();
					if ((status == GamesStatusCodes.STATUS_OK) || (status == GamesStatusCodes.STATUS_NETWORK_ERROR_STALE_DATA))
					{
						listData = new ArrayList<AchievementData>();

						AchievementBuffer achievementBuffer = results.getAchievements();

						for (int i = 0; i < achievementBuffer.getCount(); i++)
						{
							Achievement eachAchievement = achievementBuffer.get(i);

							AchievementInfo info = new AchievementInfo(eachAchievement);
							achievementsData.put(eachAchievement.getAchievementId().trim(), info);
							Debug.log(TAG, "Added "+ eachAchievement.getAchievementId() + "to achievementsData : " + achievementsData.size() + "   " + getJSONString(achievementsData));

							if (!loadAll)
							{
								//Check if this is reported earlier or not. If not reported, don't send the info.
								if (info.lastReportedDate == -1)
								{
									continue;
								}
							}

							listData.add(DataConversionUtils.getAchievementData(info));
						}

						achievementBuffer.close();
						achievementBuffer.release();
					}
					else
					{
						error = GamesStatusCodes.getStatusString(status);
						Debug.error(CommonDefines.GAME_SERVICES_TAG, "Error loading achievements info " + error);
					}

					//Send the results to listener
					if (reportListener)
					{
						if (loadAll)
						{
							if (listener != null)
							{
								listener.onLoadAchievementDetails(listData, error);
							}
						}
						else
						{
							if (listener != null)
							{
								listener.onLoadUserAchievements(listData, error);
							}
						}
					}

				}
			});
	}

	public void showUI(Context context)
	{
		//startActivityForResult(Games.Achievements.getAchievementsIntent(mGoogleApiClient), REQUEST_ACHIEVEMENTS);
		Intent intent = new Intent(context, GooglePlayGameUIActivity.class);
		intent.putExtra(Keys.TYPE, Keys.GameServices.SHOW_ACHIEVEMENTS);
		context.startActivity(intent);
	}

	public AchievementData getAchievementData(String achievementId)
	{
		AchievementInfo info = GetAchievement(achievementId);
		if (info != null)
		{
			return DataConversionUtils.getAchievementData(info);
		}
		else
		{
			return null;
		}
	}

	AchievementInfo GetAchievement(String id)
	{
		id = id.trim();
		AchievementInfo info = achievementsData.get(id);

		if (info == null)
		{
			Debug.error(TAG, "AchievementsData ID : " + id + " Contains Key : " + achievementsData.containsKey(id));
			Debug.error(TAG, "AchievementsData : " + getJSONString(achievementsData));//JSONUtility.getJSONString(achievementsData));
			Debug.error(TAG, "Achievements Data doesn't contain this achievement id. Did you load Achievement Descriptions ahead?  ID : " + id);

		}
		else
		{
			Debug.log(TAG, "Id : " + id + "   "  + info.toString());
		}

		return info;
	}

	String getJSONString (HashMap hash)
	{
		return NativePluginHelper.getConvertedHashMap(hash);
	}
}


