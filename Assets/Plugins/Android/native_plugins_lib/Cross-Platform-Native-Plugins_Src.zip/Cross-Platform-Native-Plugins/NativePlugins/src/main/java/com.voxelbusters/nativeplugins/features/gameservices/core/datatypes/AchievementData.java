package com.voxelbusters.nativeplugins.features.gameservices.core.datatypes;

import com.voxelbusters.nativeplugins.defines.Keys;

import java.util.HashMap;

/**
 * Created by ayyappa on 11/05/16.
 */
public class AchievementData
{
    public String identifier;
    public String name;
    public String unAchievedDescription;
    public String achievedDescription;
    public String imagePath;
    public int currentSteps;
    public int totalSteps;
    public long lastReportedDate;
    public boolean isCompleted;
    public String state;
    public String type;


    public HashMap<String, Object> getHashMap()
    {
        HashMap<String, Object> map = new HashMap<String, Object>();

        map.put(Keys.GameServices.ACHIEVEMENT_ID, identifier);
        map.put(Keys.GameServices.ACHIEVEMENT_TITLE, name);
        map.put(Keys.GameServices.UNACHIEVED_DESCRIPTION, unAchievedDescription);
        map.put(Keys.GameServices.ACHIEVED_DESCRIPTION, achievedDescription);//No info for this.

        map.put(Keys.GameServices.IMAGE_PATH, imagePath);

        //Here if its not incremental, check if its reveled, if not set it to zero
        map.put(Keys.GameServices.POINTS_SCORED, currentSteps);
        map.put(Keys.GameServices.MAXIMUM_POINTS, totalSteps);

        map.put(Keys.GameServices.LAST_REPORT_DATE, lastReportedDate); // This will be -1 if not reported
        map.put(Keys.GameServices.IS_COMPLETED, isCompleted ? "true" : "false");

        map.put(Keys.GameServices.STATE, state);

        map.put(Keys.GameServices.TYPE, type);

        return map;
    }
}
