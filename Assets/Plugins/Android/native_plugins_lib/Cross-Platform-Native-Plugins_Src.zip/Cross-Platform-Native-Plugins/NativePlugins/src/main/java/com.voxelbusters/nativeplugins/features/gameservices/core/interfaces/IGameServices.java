package com.voxelbusters.nativeplugins.features.gameservices.core.interfaces;

import com.voxelbusters.nativeplugins.features.gameservices.core.datatypes.AchievementData;

import java.util.HashMap;

public interface IGameServices
{

	/*
	To check if service is available
	Returns true if Game Services is available, else false
	 */
	boolean isAvailable();

	/*
	This is for creating an api client used for getting connected to the service. Mainly for setup. It takes parameter to enable cloud save if required.
	 */
	void register(boolean useCloudServices);

	/*
	Add Auth listener and player listener to the service
	 */
	void addListener(IGameServicesAuthListener auth, IGameServicesPlayerListener player);

	/*
	Remove Auth listener and player listener to the service
	 */
	void removeListener(IGameServicesAuthListener auth, IGameServicesPlayerListener player);

	//Authentication
	/*
	Initiate the login action
	 */
	void signIn();

	/*
	Initiate the signout action
	 */
	void signOut();

	/*
	Check if the services is logged in. Returns true if already logged in. Else false.
	 */
	boolean isSignedIn();

	//Achievements

	/*
	Report points for an achievement
	instanceId - Can be used for sending callbacks as there can be multiple calls to this method in parallel.
	achievementId - achievement for which score needs to be reported
	points - points that need to be reported
	immediate - Should the callback need to be synchronous(instant) or async.
	 */
	void reportProgress(String instanceId, String achievementId, int points, boolean immediate);

	/*
	Load all achievements details and send callback to the listener once loaded.
	 */
	void loadAllAchievements();

	/*
        Load user achievements details (which he achieved) and send callback to the listener once loaded.
    */
	void loadUserAchievements();

	/*
	Get Acheivement data for the specified acheivementId. Check AchievementData class for details required.
	 */
	AchievementData getAchievementData(String achievementId);

	/*
		Display default UI for achievements.
	*/
	void showAchievementsUi();

	//Leaderboards


	/*
		Submit a score for a leaderboardid
	*/
	void reportScore(String instanceId, String leaderboardId, long score, boolean immediate);

	/*
	Display default UI for leaderboards. Time span is for specifing time - weekly/monthly/alltime
	 */
	void showLeaderboardsUi(String leaderboardId, int timeSpan);

	//Misc Details


	/*
	Fetch User detail for an user.
	 */
	void loadUsers(String instanceId, String[] userIdList);

	/*
	Local player details - Fetch the logged in user details. Logged in user is called Local User.
	 */
	void requestLocalPlayerDetails();

	/*
	Get logged in user friends list
	 */
	void loadLocalPlayerFriends(boolean forceLoad);

	//Load scores for a given leaderboard.

	/*
	Load player centered scores for a specified leaderboard.
	 */
	void loadPlayerCenteredScores(String instanceId, String leaderBoardId, int timeScope, int userScope, int count);

	/*
	Load top scores for a specified leaderboard.
	 */
	void loadTopScores(String instanceId, String leaderBoardId, int timeScope, int userScope, int count);

	/*
	Load more scores for a specified leaderboard given the direction. This needs to be used along with (and after) the above two apis..
	 */
	void loadMoreScrores(String instanceId, String leaderBoardId, int direction, int count);

	/*
	Load signed in player profile image - IGNORE this
	 */
	void loadProfileImage(String instanceId, String uriString);

	/*
	Request authentication token so that the services can be accessed from out side the app (from backend)
	 */
	void requestAuthToken(String clientId);

}
