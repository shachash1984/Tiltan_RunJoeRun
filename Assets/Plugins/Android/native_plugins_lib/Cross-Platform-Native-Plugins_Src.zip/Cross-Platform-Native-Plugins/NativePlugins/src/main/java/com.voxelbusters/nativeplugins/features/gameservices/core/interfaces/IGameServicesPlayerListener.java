package com.voxelbusters.nativeplugins.features.gameservices.core.interfaces;

import com.voxelbusters.nativeplugins.features.gameservices.core.datatypes.AchievementData;
import com.voxelbusters.nativeplugins.features.gameservices.core.datatypes.Score;
import com.voxelbusters.nativeplugins.features.gameservices.core.datatypes.User;

import java.util.ArrayList;

public interface IGameServicesPlayerListener
{
	/*
		Callback for report progress action
	 */
	void onReportProgress(String instanceID, AchievementData achievementData, String error);

	/*
		Callback for report load scores
	 */
	void onLoadingScores(String instanceId, Score localPlayerScore, ArrayList<Score> scores, String error);

	/*
		Callback for load all achievement details
	 */
	void onLoadAchievementDetails(ArrayList<AchievementData> achievementdata, String error);

	/*
		Callback for user achievement details
	 */
	void onLoadUserAchievements(ArrayList<AchievementData> achievements, String error);

	/*
		Callback for local user friend details
	 */
	void onLoadLocalUserFriendsDetails(ArrayList<User> friends, String error);

	/*
		Callback for local user details
	 */
	void onLoadLocalUserDetails(User user);

	/*
		Callback for getting requested user profiles
	 */
	void onLoadUserProfiles(String instanceId, ArrayList<User> result, String error);

	/*
		Callback for load picture - Ignore
	 */
	void onLoadProfilePicture(String instanceId, String filePath, String error);

	/*
		Callback for report score
	 */
	void onReportScore(String instanceId, Score score, String error);

	/*
		Callback once Leaderboards UI is closed
	 */
	void onLeaderboardsUIClosed();

	/*
		Callback once Achievements UI is closed
	 */
	void onAchievementsUIClosed();
}
