package com.voxelbusters.nativeplugins.utilities;

import android.Manifest;
import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.content.PermissionChecker;

import com.voxelbusters.nativeplugins.NativePluginHelper;
import com.voxelbusters.nativeplugins.helpers.PermissionRequestFragment;
import com.voxelbusters.nativeplugins.helpers.interfaces.IPermissionRequestCallback;

import java.util.ArrayList;

/**
 * Created by ayyappa on 22/09/17.
 */

public class PermissionUtility
{

    public static boolean hasPermission(String permission)
    {
        int permissionCheck = PermissionChecker.checkSelfPermission(NativePluginHelper.getCurrentActivity(),
                permission);

        return (permissionCheck == PackageManager.PERMISSION_GRANTED);
    }

    public static boolean verifyPermissions(int[] grantResults) {
        // At least one result must be checked.
        if(grantResults.length < 1){
            return false;
        }

        // Verify that each required permission has been granted, otherwise return false.
        for (int result : grantResults) {
            if (result != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    public static void requestPermission(String permission, String infoMessage, IPermissionRequestCallback callback)
    {
        ArrayList<String> arrayList = new ArrayList<String>();
        arrayList.add(permission);
        requestPermissions(arrayList, infoMessage, callback);
    }

    public static void requestPermissions(ArrayList<String> permissions, String infoMessage, IPermissionRequestCallback callback)
    {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M)
        {
            if(callback != null)
            {
                callback.onPermissionGrant();
            }
            return;
        }

        ArrayList<String> updatedPermissions = new ArrayList<String>();

        for(String eachPermission : permissions)
        {
            if(!PermissionUtility.hasPermission(eachPermission))
            {
                updatedPermissions.add(eachPermission);
            }
        }

        if(updatedPermissions.size() == 0)
        {
            if(callback != null)
            {
                callback.onPermissionGrant();
            }

            return;
        }

        final PermissionRequestFragment permissionRequest = new PermissionRequestFragment();
        permissionRequest.setCallback(callback);

        Activity activity = NativePluginHelper.getCurrentActivity();
        Bundle bundle = new Bundle();

        bundle.putStringArray(PermissionRequestFragment.PERMISSION_LIST, updatedPermissions.toArray(new String[permissions.size()]));
        bundle.putString(PermissionRequestFragment.MESSAGE_INFO, infoMessage);
        permissionRequest.setArguments(bundle);

        FragmentTransaction fragmentTransaction = activity.getFragmentManager().beginTransaction();
        fragmentTransaction.add(0, permissionRequest);
        fragmentTransaction.commit();
    }
}
