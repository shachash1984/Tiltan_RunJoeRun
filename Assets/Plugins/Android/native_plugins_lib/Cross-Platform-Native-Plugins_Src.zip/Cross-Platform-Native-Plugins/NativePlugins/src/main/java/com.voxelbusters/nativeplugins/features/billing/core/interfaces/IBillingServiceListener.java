package com.voxelbusters.nativeplugins.features.billing.core.interfaces;

import com.voxelbusters.nativeplugins.features.billing.core.datatypes.BillingProduct;
import com.voxelbusters.nativeplugins.features.billing.core.datatypes.BillingTransaction;

import java.util.ArrayList;

public interface IBillingServiceListener
{
	void onSetupFinished(Boolean isBillingAvialable);

	void onRequestProductsFinished(ArrayList<BillingProduct> productDetails, String error);

	void onPurchaseTransactionFinished(ArrayList<BillingTransaction> transactionList, String error);

	void onRestoreTransactionFinished(ArrayList<BillingTransaction> transactionList, String error);
}
